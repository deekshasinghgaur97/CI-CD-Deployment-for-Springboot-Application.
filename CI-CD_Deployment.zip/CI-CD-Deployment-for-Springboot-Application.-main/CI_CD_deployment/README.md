# cicd-demo
Simple spring boot app to showcase Docker, Jenkins and Kubernetes
